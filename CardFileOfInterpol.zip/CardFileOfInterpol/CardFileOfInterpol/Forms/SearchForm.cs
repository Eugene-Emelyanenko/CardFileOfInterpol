﻿using CardFileOfInterpol.Data;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace CardFileOfInterpol
{
    public partial class SearchForm : Form
    {
        public SearchForm()
        {
            InitializeComponent();
        }
        public static List<Criminal> SearchCriminal(string line, List<Criminal> criminals)
        {
            List<Criminal> result = new List<Criminal>();
            var t = line.ToLower();
            foreach (Criminal criminal in criminals)
            {
                if (criminal.ToString().ToLower().IndexOf(t) > -1)
                {
                    result.Add(criminal);
                }
            }
            return result;
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            if(SearchBox.Text == string.Empty)
            {
                ListOfCriminals.Items.Clear();
                foreach (Criminal criminal in DateOfProgram.criminals)
                {
                    ListOfCriminals.Items.Add(criminal.GetInfo());
                }
            }
            else
            {
                DateOfProgram.SearchedCriminals = SearchCriminal(SearchBox.Text, DateOfProgram.criminals);
                ListOfCriminals.Items.Clear();
                foreach (Criminal criminal in DateOfProgram.SearchedCriminals)
                {
                    ListOfCriminals.Items.Add(criminal.GetInfo());
                }
            }
        }

        private void ListOfCriminals_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                foreach (Criminal criminal in DateOfProgram.criminals)
                {
                    if (criminal.GetInfo() == ListOfCriminals.SelectedItem.ToString())
                    {
                        InfoForm infoForm = new InfoForm(criminal);
                        infoForm.FormClosed += (eventSender, eventArgs) => Show();
                        infoForm.Show();
                        Hide();
                    }
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Оберіть злочинця");
            }

        }

        private void ButtonSort_Click(object sender, EventArgs e)
        {
            DateOfProgram.criminals.Sort((c1, c2) => string.Compare(c1.Name, c2.Name, StringComparison.Ordinal));
            Serialization.SerializeObjects(DateOfProgram.criminals);
            ListOfCriminals.Items.Clear();
            foreach (Criminal criminal in DateOfProgram.criminals)
            {
                ListOfCriminals.Items.Add(criminal.GetInfo());
            }
        }

        private void ButtonRefresh_Click(object sender, EventArgs e)
        {
            ListOfCriminals.Items.Clear();
            if (SearchBox.Text == string.Empty)
            {
                ListOfCriminals.Items.Clear();
                foreach (Criminal criminal in DateOfProgram.criminals)
                {
                    ListOfCriminals.Items.Add(criminal.GetInfo());
                }
            }
            else
            {
                DateOfProgram.SearchedCriminals = SearchCriminal(SearchBox.Text, DateOfProgram.criminals);
                ListOfCriminals.Items.Clear();
                foreach (Criminal criminal in DateOfProgram.SearchedCriminals)
                {
                    ListOfCriminals.Items.Add(criminal.GetInfo());
                }
            }
        }
    }
}
