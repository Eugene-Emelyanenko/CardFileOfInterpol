﻿using CardFileOfInterpol.Data;
using System;
using System.Windows.Forms;

namespace CardFileOfInterpol
{
    public partial class InfoForm : Form
    {
        string[] ways = new string[] { "Архів", "Список" };
        string currentWay = "";
        public InfoForm()
        {
            InitializeComponent();
        }
        public InfoForm(Criminal criminal)
        {
            InitializeComponent();
            DateOfProgram.currentCriminal = criminal;
            ShowInfo(criminal);
            comboBoxWays.Items.AddRange(ways);
            comboBoxWays.SelectedItem = ways[0];
        }
        public void ShowInfo(Criminal criminal)
        {
            textBoxName.Text = criminal.Name;
            textBoxSecondName.Text = criminal.SecondName;
            textBoxCitiezenShip.Text = criminal.CitiezenShip;
            textBoxCriminalProfession.Text = criminal.CriminalProfession;
            textBoxGroup.Text = criminal.GroupName;
            textBoxAlias.Text = criminal.Alias;
            textBoxEyeColor.Text = criminal.EyeColor;
            textBoxHairColor.Text = criminal.HairColor;
            textBoxOmens.Text = criminal.GetOmens();
            textBoxPlaceOfBirth.Text = criminal.PlaceOfBirth;
            textBoxDateOfBirth.Text = criminal.DateOfBirth.ToString("dd'/'MM'/'yyyy");
            textBoxLastPlace.Text = criminal.LastPlaceOfLiving;
            textBoxLanguages.Text = criminal.GetLanguages();
            textBoxLastThing.Text = criminal.LastThing;
            if(criminal.Alive == true)
            {
                textBoxAlive.Text = "Live";
            }
            else
            {
                textBoxAlive.Text = "Dead";
            }
            textBoxHeight.Text = criminal.Height.ToString();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ButtonToArchive_Click(object sender, EventArgs e)
        {
            if (currentWay == "Архів")//до архіву
            {
                DialogeForm dialogeForm = new DialogeForm();
                dialogeForm.ShowDialog();
                if(dialogeForm.DialogResult == DialogResult.OK)
                {
                    if (DateOfProgram.criminals.Contains(DateOfProgram.currentCriminal) && !DateOfProgram.archive.Contains(DateOfProgram.currentCriminal))
                    {
                        DateOfProgram.archive.Add(DateOfProgram.currentCriminal);
                        Serialization.SerializeObjects(DateOfProgram.archive, Serialization.DATA_PATH_ARCHIVE);

                        DateOfProgram.criminals.Remove(DateOfProgram.currentCriminal);
                        Serialization.SerializeObjects(DateOfProgram.criminals);
                        MessageBox.Show("Злочинець тепер у архіві");
                    }
                    else
                    {
                        MessageBox.Show("Злочинець вже у архіві! Операцію скасовано");
                    }
                }
            }
            else if(currentWay == "Список")//до списку
            {
                DialogeForm dialogeForm = new DialogeForm();
                dialogeForm.ShowDialog();
                if (dialogeForm.DialogResult == DialogResult.OK)
                {
                    if (!DateOfProgram.criminals.Contains(DateOfProgram.currentCriminal) && DateOfProgram.archive.Contains(DateOfProgram.currentCriminal))
                    {
                        DateOfProgram.archive.Remove(DateOfProgram.currentCriminal);
                        Serialization.SerializeObjects(DateOfProgram.archive, Serialization.DATA_PATH_ARCHIVE);

                        DateOfProgram.criminals.Add(DateOfProgram.currentCriminal);
                        Serialization.SerializeObjects(DateOfProgram.criminals);
                        MessageBox.Show("Злочинець тепер у списку");
                    }
                    else
                    {
                        MessageBox.Show("Злочинець вже у списку! Операцію скасовано");
                    }
                }
            }
            else
            {
                MessageBox.Show("Оберіть куди треба перенести злочинця!");
            }
        }

        private void comboBoxWays_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ways[0] == comboBoxWays.SelectedItem.ToString())
            {
                currentWay = ways[0];
            }
            else
            {
                currentWay = ways[1];
            }
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            if(DateOfProgram.currentCriminal.Alive == false)
            {
                DialogeForm dialogeForm = new DialogeForm();
                dialogeForm.ShowDialog();
                if (dialogeForm.DialogResult == DialogResult.OK)
                {
                    if (DateOfProgram.archive.Contains(DateOfProgram.currentCriminal))
                    {
                        DateOfProgram.archive.Remove(DateOfProgram.currentCriminal);
                        Serialization.SerializeObjects(DateOfProgram.archive, Serialization.DATA_PATH_ARCHIVE);
                    }
                    else if (DateOfProgram.criminals.Contains(DateOfProgram.currentCriminal))
                    {
                        DateOfProgram.criminals.Remove(DateOfProgram.currentCriminal);
                        Serialization.SerializeObjects(DateOfProgram.criminals);
                    }
                    MessageBox.Show("Злочинець був видалений");
                }
            }

            else
            {
                MessageBox.Show("Злочинець ще живий! Операцію скасовано");
            }
        }

        private void buttonGroupInfo_Click(object sender, EventArgs e)
        {
            GroupInfoForm groupInfoForm = new GroupInfoForm(DateOfProgram.currentCriminal.GroupName);
            groupInfoForm.FormClosed += (eventSender, eventArgs) => Show();
            groupInfoForm.Show();
            Hide();
        }
    }
}
