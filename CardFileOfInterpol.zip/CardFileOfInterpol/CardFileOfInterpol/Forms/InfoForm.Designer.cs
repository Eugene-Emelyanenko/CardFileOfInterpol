﻿namespace CardFileOfInterpol
{
    partial class InfoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MainPanel = new System.Windows.Forms.Label();
            this.MainFeaturesLabel = new System.Windows.Forms.Label();
            this.BackButton = new System.Windows.Forms.Button();
            this.MainFeaturesPanel = new System.Windows.Forms.Panel();
            this.buttonGroupInfo = new System.Windows.Forms.Button();
            this.textBoxHeight = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textBoxAlive = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textBoxAlias = new System.Windows.Forms.TextBox();
            this.textBoxCriminalProfession = new System.Windows.Forms.TextBox();
            this.textBoxGroup = new System.Windows.Forms.TextBox();
            this.textBoxCitiezenShip = new System.Windows.Forms.TextBox();
            this.textBoxSecondName = new System.Windows.Forms.TextBox();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.AdditionalFeaturesPanel = new System.Windows.Forms.Panel();
            this.textBoxLastPlace = new System.Windows.Forms.TextBox();
            this.textBoxLastThing = new System.Windows.Forms.TextBox();
            this.textBoxLanguages = new System.Windows.Forms.TextBox();
            this.textBoxDateOfBirth = new System.Windows.Forms.TextBox();
            this.textBoxPlaceOfBirth = new System.Windows.Forms.TextBox();
            this.textBoxOmens = new System.Windows.Forms.TextBox();
            this.textBoxHairColor = new System.Windows.Forms.TextBox();
            this.textBoxEyeColor = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.AdditionalFituresLabel = new System.Windows.Forms.Label();
            this.ButtonToArchive = new System.Windows.Forms.Button();
            this.DeleteButton = new System.Windows.Forms.Button();
            this.comboBoxWays = new System.Windows.Forms.ComboBox();
            this.MainFeaturesPanel.SuspendLayout();
            this.AdditionalFeaturesPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainPanel
            // 
            this.MainPanel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.MainPanel.AutoSize = true;
            this.MainPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MainPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainPanel.Location = new System.Drawing.Point(426, 20);
            this.MainPanel.Name = "MainPanel";
            this.MainPanel.Padding = new System.Windows.Forms.Padding(10);
            this.MainPanel.Size = new System.Drawing.Size(327, 51);
            this.MainPanel.TabIndex = 2;
            this.MainPanel.Text = "Інформація про злочинця";
            this.MainPanel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MainFeaturesLabel
            // 
            this.MainFeaturesLabel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.MainFeaturesLabel.AutoSize = true;
            this.MainFeaturesLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MainFeaturesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainFeaturesLabel.Location = new System.Drawing.Point(12, 102);
            this.MainFeaturesLabel.Name = "MainFeaturesLabel";
            this.MainFeaturesLabel.Padding = new System.Windows.Forms.Padding(5);
            this.MainFeaturesLabel.Size = new System.Drawing.Size(155, 32);
            this.MainFeaturesLabel.TabIndex = 3;
            this.MainFeaturesLabel.Text = "Основні ознаки:";
            // 
            // BackButton
            // 
            this.BackButton.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.BackButton.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.BackButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BackButton.Location = new System.Drawing.Point(12, 12);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(60, 60);
            this.BackButton.TabIndex = 6;
            this.BackButton.Text = "←";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // MainFeaturesPanel
            // 
            this.MainFeaturesPanel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.MainFeaturesPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MainFeaturesPanel.Controls.Add(this.buttonGroupInfo);
            this.MainFeaturesPanel.Controls.Add(this.textBoxHeight);
            this.MainFeaturesPanel.Controls.Add(this.label16);
            this.MainFeaturesPanel.Controls.Add(this.textBoxAlive);
            this.MainFeaturesPanel.Controls.Add(this.label15);
            this.MainFeaturesPanel.Controls.Add(this.textBoxAlias);
            this.MainFeaturesPanel.Controls.Add(this.textBoxCriminalProfession);
            this.MainFeaturesPanel.Controls.Add(this.textBoxGroup);
            this.MainFeaturesPanel.Controls.Add(this.textBoxCitiezenShip);
            this.MainFeaturesPanel.Controls.Add(this.textBoxSecondName);
            this.MainFeaturesPanel.Controls.Add(this.textBoxName);
            this.MainFeaturesPanel.Controls.Add(this.label6);
            this.MainFeaturesPanel.Controls.Add(this.label5);
            this.MainFeaturesPanel.Controls.Add(this.label4);
            this.MainFeaturesPanel.Controls.Add(this.label3);
            this.MainFeaturesPanel.Controls.Add(this.label2);
            this.MainFeaturesPanel.Controls.Add(this.label1);
            this.MainFeaturesPanel.Location = new System.Drawing.Point(12, 146);
            this.MainFeaturesPanel.Name = "MainFeaturesPanel";
            this.MainFeaturesPanel.Size = new System.Drawing.Size(558, 415);
            this.MainFeaturesPanel.TabIndex = 7;
            // 
            // buttonGroupInfo
            // 
            this.buttonGroupInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonGroupInfo.Location = new System.Drawing.Point(169, 263);
            this.buttonGroupInfo.Name = "buttonGroupInfo";
            this.buttonGroupInfo.Size = new System.Drawing.Size(34, 34);
            this.buttonGroupInfo.TabIndex = 23;
            this.buttonGroupInfo.Text = "...";
            this.buttonGroupInfo.UseVisualStyleBackColor = true;
            this.buttonGroupInfo.Click += new System.EventHandler(this.buttonGroupInfo_Click);
            // 
            // textBoxHeight
            // 
            this.textBoxHeight.Location = new System.Drawing.Point(200, 115);
            this.textBoxHeight.Multiline = true;
            this.textBoxHeight.Name = "textBoxHeight";
            this.textBoxHeight.ReadOnly = true;
            this.textBoxHeight.Size = new System.Drawing.Size(321, 32);
            this.textBoxHeight.TabIndex = 22;
            this.textBoxHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(23, 115);
            this.label16.Name = "label16";
            this.label16.Padding = new System.Windows.Forms.Padding(5);
            this.label16.Size = new System.Drawing.Size(71, 32);
            this.label16.TabIndex = 21;
            this.label16.Text = "Зріст:";
            // 
            // textBoxAlive
            // 
            this.textBoxAlive.Location = new System.Drawing.Point(200, 365);
            this.textBoxAlive.Multiline = true;
            this.textBoxAlive.Name = "textBoxAlive";
            this.textBoxAlive.ReadOnly = true;
            this.textBoxAlive.Size = new System.Drawing.Size(321, 32);
            this.textBoxAlive.TabIndex = 20;
            this.textBoxAlive.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.Location = new System.Drawing.Point(23, 365);
            this.label15.Name = "label15";
            this.label15.Padding = new System.Windows.Forms.Padding(5);
            this.label15.Size = new System.Drawing.Size(153, 32);
            this.label15.TabIndex = 19;
            this.label15.Text = "Життєвий стан:";
            // 
            // textBoxAlias
            // 
            this.textBoxAlias.Location = new System.Drawing.Point(200, 315);
            this.textBoxAlias.Multiline = true;
            this.textBoxAlias.Name = "textBoxAlias";
            this.textBoxAlias.ReadOnly = true;
            this.textBoxAlias.Size = new System.Drawing.Size(321, 32);
            this.textBoxAlias.TabIndex = 18;
            this.textBoxAlias.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxCriminalProfession
            // 
            this.textBoxCriminalProfession.Location = new System.Drawing.Point(200, 214);
            this.textBoxCriminalProfession.Multiline = true;
            this.textBoxCriminalProfession.Name = "textBoxCriminalProfession";
            this.textBoxCriminalProfession.ReadOnly = true;
            this.textBoxCriminalProfession.Size = new System.Drawing.Size(321, 30);
            this.textBoxCriminalProfession.TabIndex = 17;
            this.textBoxCriminalProfession.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxGroup
            // 
            this.textBoxGroup.Location = new System.Drawing.Point(200, 263);
            this.textBoxGroup.Multiline = true;
            this.textBoxGroup.Name = "textBoxGroup";
            this.textBoxGroup.ReadOnly = true;
            this.textBoxGroup.Size = new System.Drawing.Size(321, 32);
            this.textBoxGroup.TabIndex = 16;
            this.textBoxGroup.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxCitiezenShip
            // 
            this.textBoxCitiezenShip.Location = new System.Drawing.Point(200, 165);
            this.textBoxCitiezenShip.Multiline = true;
            this.textBoxCitiezenShip.Name = "textBoxCitiezenShip";
            this.textBoxCitiezenShip.ReadOnly = true;
            this.textBoxCitiezenShip.Size = new System.Drawing.Size(321, 32);
            this.textBoxCitiezenShip.TabIndex = 15;
            this.textBoxCitiezenShip.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxSecondName
            // 
            this.textBoxSecondName.Location = new System.Drawing.Point(200, 65);
            this.textBoxSecondName.Multiline = true;
            this.textBoxSecondName.Name = "textBoxSecondName";
            this.textBoxSecondName.ReadOnly = true;
            this.textBoxSecondName.Size = new System.Drawing.Size(321, 32);
            this.textBoxSecondName.TabIndex = 14;
            this.textBoxSecondName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(200, 15);
            this.textBoxName.Multiline = true;
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.ReadOnly = true;
            this.textBoxName.Size = new System.Drawing.Size(321, 32);
            this.textBoxName.TabIndex = 13;
            this.textBoxName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(23, 315);
            this.label6.Name = "label6";
            this.label6.Padding = new System.Windows.Forms.Padding(5);
            this.label6.Size = new System.Drawing.Size(86, 32);
            this.label6.TabIndex = 5;
            this.label6.Text = "Кличка:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(23, 263);
            this.label5.Name = "label5";
            this.label5.Padding = new System.Windows.Forms.Padding(5);
            this.label5.Size = new System.Drawing.Size(131, 32);
            this.label5.TabIndex = 4;
            this.label5.Text = "Угрупування:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(23, 214);
            this.label4.Name = "label4";
            this.label4.Padding = new System.Windows.Forms.Padding(5);
            this.label4.Size = new System.Drawing.Size(161, 30);
            this.label4.TabIndex = 3;
            this.label4.Text = "Злочинна професія:\r\n";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(23, 165);
            this.label3.Name = "label3";
            this.label3.Padding = new System.Windows.Forms.Padding(5);
            this.label3.Size = new System.Drawing.Size(149, 32);
            this.label3.TabIndex = 2;
            this.label3.Text = "Громадянство:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(23, 65);
            this.label2.Name = "label2";
            this.label2.Padding = new System.Windows.Forms.Padding(5);
            this.label2.Size = new System.Drawing.Size(106, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "Прізвище:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(23, 15);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(5);
            this.label1.Size = new System.Drawing.Size(56, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ім\'я:";
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Location = new System.Drawing.Point(753, 146);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(0, 0);
            this.panel2.TabIndex = 8;
            // 
            // AdditionalFeaturesPanel
            // 
            this.AdditionalFeaturesPanel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.AdditionalFeaturesPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AdditionalFeaturesPanel.Controls.Add(this.textBoxLastPlace);
            this.AdditionalFeaturesPanel.Controls.Add(this.textBoxLastThing);
            this.AdditionalFeaturesPanel.Controls.Add(this.textBoxLanguages);
            this.AdditionalFeaturesPanel.Controls.Add(this.textBoxDateOfBirth);
            this.AdditionalFeaturesPanel.Controls.Add(this.textBoxPlaceOfBirth);
            this.AdditionalFeaturesPanel.Controls.Add(this.textBoxOmens);
            this.AdditionalFeaturesPanel.Controls.Add(this.textBoxHairColor);
            this.AdditionalFeaturesPanel.Controls.Add(this.textBoxEyeColor);
            this.AdditionalFeaturesPanel.Controls.Add(this.label14);
            this.AdditionalFeaturesPanel.Controls.Add(this.label13);
            this.AdditionalFeaturesPanel.Controls.Add(this.label7);
            this.AdditionalFeaturesPanel.Controls.Add(this.label12);
            this.AdditionalFeaturesPanel.Controls.Add(this.label8);
            this.AdditionalFeaturesPanel.Controls.Add(this.label11);
            this.AdditionalFeaturesPanel.Controls.Add(this.label9);
            this.AdditionalFeaturesPanel.Controls.Add(this.label10);
            this.AdditionalFeaturesPanel.Location = new System.Drawing.Point(612, 146);
            this.AdditionalFeaturesPanel.Name = "AdditionalFeaturesPanel";
            this.AdditionalFeaturesPanel.Size = new System.Drawing.Size(558, 415);
            this.AdditionalFeaturesPanel.TabIndex = 8;
            // 
            // textBoxLastPlace
            // 
            this.textBoxLastPlace.Location = new System.Drawing.Point(270, 265);
            this.textBoxLastPlace.Multiline = true;
            this.textBoxLastPlace.Name = "textBoxLastPlace";
            this.textBoxLastPlace.ReadOnly = true;
            this.textBoxLastPlace.Size = new System.Drawing.Size(273, 32);
            this.textBoxLastPlace.TabIndex = 26;
            this.textBoxLastPlace.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxLastThing
            // 
            this.textBoxLastThing.Location = new System.Drawing.Point(223, 365);
            this.textBoxLastThing.Multiline = true;
            this.textBoxLastThing.Name = "textBoxLastThing";
            this.textBoxLastThing.ReadOnly = true;
            this.textBoxLastThing.Size = new System.Drawing.Size(321, 32);
            this.textBoxLastThing.TabIndex = 25;
            this.textBoxLastThing.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxLanguages
            // 
            this.textBoxLanguages.Location = new System.Drawing.Point(222, 315);
            this.textBoxLanguages.Multiline = true;
            this.textBoxLanguages.Name = "textBoxLanguages";
            this.textBoxLanguages.ReadOnly = true;
            this.textBoxLanguages.Size = new System.Drawing.Size(321, 32);
            this.textBoxLanguages.TabIndex = 24;
            this.textBoxLanguages.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxDateOfBirth
            // 
            this.textBoxDateOfBirth.Location = new System.Drawing.Point(222, 215);
            this.textBoxDateOfBirth.Multiline = true;
            this.textBoxDateOfBirth.Name = "textBoxDateOfBirth";
            this.textBoxDateOfBirth.ReadOnly = true;
            this.textBoxDateOfBirth.Size = new System.Drawing.Size(321, 32);
            this.textBoxDateOfBirth.TabIndex = 23;
            this.textBoxDateOfBirth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxPlaceOfBirth
            // 
            this.textBoxPlaceOfBirth.Location = new System.Drawing.Point(223, 165);
            this.textBoxPlaceOfBirth.Multiline = true;
            this.textBoxPlaceOfBirth.Name = "textBoxPlaceOfBirth";
            this.textBoxPlaceOfBirth.ReadOnly = true;
            this.textBoxPlaceOfBirth.Size = new System.Drawing.Size(321, 32);
            this.textBoxPlaceOfBirth.TabIndex = 22;
            this.textBoxPlaceOfBirth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxOmens
            // 
            this.textBoxOmens.Location = new System.Drawing.Point(222, 115);
            this.textBoxOmens.Multiline = true;
            this.textBoxOmens.Name = "textBoxOmens";
            this.textBoxOmens.ReadOnly = true;
            this.textBoxOmens.Size = new System.Drawing.Size(321, 32);
            this.textBoxOmens.TabIndex = 21;
            this.textBoxOmens.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxHairColor
            // 
            this.textBoxHairColor.Location = new System.Drawing.Point(222, 65);
            this.textBoxHairColor.Multiline = true;
            this.textBoxHairColor.Name = "textBoxHairColor";
            this.textBoxHairColor.ReadOnly = true;
            this.textBoxHairColor.Size = new System.Drawing.Size(321, 32);
            this.textBoxHairColor.TabIndex = 20;
            this.textBoxHairColor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxEyeColor
            // 
            this.textBoxEyeColor.Location = new System.Drawing.Point(222, 15);
            this.textBoxEyeColor.Multiline = true;
            this.textBoxEyeColor.Name = "textBoxEyeColor";
            this.textBoxEyeColor.ReadOnly = true;
            this.textBoxEyeColor.Size = new System.Drawing.Size(321, 32);
            this.textBoxEyeColor.TabIndex = 19;
            this.textBoxEyeColor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(24, 365);
            this.label14.Name = "label14";
            this.label14.Padding = new System.Windows.Forms.Padding(5);
            this.label14.Size = new System.Drawing.Size(162, 32);
            this.label14.TabIndex = 13;
            this.label14.Text = "Остання справа:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(24, 315);
            this.label13.Name = "label13";
            this.label13.Padding = new System.Windows.Forms.Padding(5);
            this.label13.Size = new System.Drawing.Size(125, 32);
            this.label13.TabIndex = 12;
            this.label13.Text = "Знання мов:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(24, 265);
            this.label7.Name = "label7";
            this.label7.Padding = new System.Windows.Forms.Padding(5);
            this.label7.Size = new System.Drawing.Size(213, 30);
            this.label7.TabIndex = 11;
            this.label7.Text = "Останнє місце проживання:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(24, 15);
            this.label12.Name = "label12";
            this.label12.Padding = new System.Windows.Forms.Padding(5);
            this.label12.Size = new System.Drawing.Size(116, 32);
            this.label12.TabIndex = 6;
            this.label12.Text = "Колір очей:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(24, 215);
            this.label8.Name = "label8";
            this.label8.Padding = new System.Windows.Forms.Padding(5);
            this.label8.Size = new System.Drawing.Size(178, 32);
            this.label8.TabIndex = 10;
            this.label8.Text = "Дата народження:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(24, 65);
            this.label11.Name = "label11";
            this.label11.Padding = new System.Windows.Forms.Padding(5);
            this.label11.Size = new System.Drawing.Size(144, 32);
            this.label11.TabIndex = 7;
            this.label11.Text = "Колір волосся:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(24, 165);
            this.label9.Name = "label9";
            this.label9.Padding = new System.Windows.Forms.Padding(5);
            this.label9.Size = new System.Drawing.Size(182, 32);
            this.label9.TabIndex = 9;
            this.label9.Text = "Місце народження:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(24, 115);
            this.label10.Name = "label10";
            this.label10.Padding = new System.Windows.Forms.Padding(5);
            this.label10.Size = new System.Drawing.Size(110, 32);
            this.label10.TabIndex = 8;
            this.label10.Text = "Прикмети:";
            // 
            // AdditionalFituresLabel
            // 
            this.AdditionalFituresLabel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.AdditionalFituresLabel.AutoSize = true;
            this.AdditionalFituresLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AdditionalFituresLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AdditionalFituresLabel.Location = new System.Drawing.Point(993, 102);
            this.AdditionalFituresLabel.Name = "AdditionalFituresLabel";
            this.AdditionalFituresLabel.Padding = new System.Windows.Forms.Padding(5);
            this.AdditionalFituresLabel.Size = new System.Drawing.Size(177, 32);
            this.AdditionalFituresLabel.TabIndex = 9;
            this.AdditionalFituresLabel.Text = "Додаткові ознаки:";
            // 
            // ButtonToArchive
            // 
            this.ButtonToArchive.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ButtonToArchive.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ButtonToArchive.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonToArchive.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ButtonToArchive.Location = new System.Drawing.Point(59, 594);
            this.ButtonToArchive.Name = "ButtonToArchive";
            this.ButtonToArchive.Size = new System.Drawing.Size(279, 75);
            this.ButtonToArchive.TabIndex = 10;
            this.ButtonToArchive.Text = "Перенести";
            this.ButtonToArchive.UseVisualStyleBackColor = false;
            this.ButtonToArchive.Click += new System.EventHandler(this.ButtonToArchive_Click);
            // 
            // DeleteButton
            // 
            this.DeleteButton.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.DeleteButton.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.DeleteButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DeleteButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DeleteButton.Location = new System.Drawing.Point(753, 594);
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(279, 75);
            this.DeleteButton.TabIndex = 11;
            this.DeleteButton.Text = "Видалити";
            this.DeleteButton.UseVisualStyleBackColor = false;
            this.DeleteButton.Click += new System.EventHandler(this.DeleteButton_Click);
            // 
            // comboBoxWays
            // 
            this.comboBoxWays.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.comboBoxWays.Location = new System.Drawing.Point(344, 594);
            this.comboBoxWays.Name = "comboBoxWays";
            this.comboBoxWays.Size = new System.Drawing.Size(226, 24);
            this.comboBoxWays.Sorted = true;
            this.comboBoxWays.TabIndex = 12;
            this.comboBoxWays.SelectedIndexChanged += new System.EventHandler(this.comboBoxWays_SelectedIndexChanged);
            // 
            // InfoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(1182, 703);
            this.Controls.Add(this.comboBoxWays);
            this.Controls.Add(this.DeleteButton);
            this.Controls.Add(this.ButtonToArchive);
            this.Controls.Add(this.AdditionalFituresLabel);
            this.Controls.Add(this.AdditionalFeaturesPanel);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.MainFeaturesPanel);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.MainFeaturesLabel);
            this.Controls.Add(this.MainPanel);
            this.Name = "InfoForm";
            this.Text = "Info";
            this.MainFeaturesPanel.ResumeLayout(false);
            this.MainFeaturesPanel.PerformLayout();
            this.AdditionalFeaturesPanel.ResumeLayout(false);
            this.AdditionalFeaturesPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label MainPanel;
        private System.Windows.Forms.Label MainFeaturesLabel;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Panel MainFeaturesPanel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel AdditionalFeaturesPanel;
        private System.Windows.Forms.Label AdditionalFituresLabel;
        private System.Windows.Forms.Button ButtonToArchive;
        private System.Windows.Forms.Button DeleteButton;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxAlias;
        private System.Windows.Forms.TextBox textBoxCriminalProfession;
        private System.Windows.Forms.TextBox textBoxGroup;
        private System.Windows.Forms.TextBox textBoxCitiezenShip;
        private System.Windows.Forms.TextBox textBoxSecondName;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.TextBox textBoxLastPlace;
        private System.Windows.Forms.TextBox textBoxLastThing;
        private System.Windows.Forms.TextBox textBoxLanguages;
        private System.Windows.Forms.TextBox textBoxDateOfBirth;
        private System.Windows.Forms.TextBox textBoxPlaceOfBirth;
        private System.Windows.Forms.TextBox textBoxOmens;
        private System.Windows.Forms.TextBox textBoxHairColor;
        private System.Windows.Forms.TextBox textBoxEyeColor;
        private System.Windows.Forms.TextBox textBoxAlive;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBoxHeight;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox comboBoxWays;
        public System.Windows.Forms.Button buttonGroupInfo;
    }
}