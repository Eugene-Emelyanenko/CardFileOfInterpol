﻿namespace CardFileOfInterpol
{
    partial class SearchForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SearchButton = new System.Windows.Forms.Button();
            this.SearchBox = new System.Windows.Forms.TextBox();
            this.ButtonSort = new System.Windows.Forms.Button();
            this.ArchivePanel = new System.Windows.Forms.Panel();
            this.MainPanel = new System.Windows.Forms.Label();
            this.ListOfCriminals = new System.Windows.Forms.ListBox();
            this.BackButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.ButtonRefresh = new System.Windows.Forms.Button();
            this.ArchivePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // SearchButton
            // 
            this.SearchButton.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.SearchButton.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.SearchButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SearchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SearchButton.Location = new System.Drawing.Point(491, 123);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(193, 44);
            this.SearchButton.TabIndex = 29;
            this.SearchButton.Text = "Знайти";
            this.SearchButton.UseVisualStyleBackColor = false;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // SearchBox
            // 
            this.SearchBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.SearchBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SearchBox.Location = new System.Drawing.Point(418, 83);
            this.SearchBox.MaxLength = 50;
            this.SearchBox.Multiline = true;
            this.SearchBox.Name = "SearchBox";
            this.SearchBox.Size = new System.Drawing.Size(333, 34);
            this.SearchBox.TabIndex = 30;
            // 
            // ButtonSort
            // 
            this.ButtonSort.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ButtonSort.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ButtonSort.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonSort.Location = new System.Drawing.Point(1017, 123);
            this.ButtonSort.Name = "ButtonSort";
            this.ButtonSort.Size = new System.Drawing.Size(153, 47);
            this.ButtonSort.TabIndex = 27;
            this.ButtonSort.Text = "Відсортирувати за алфавітом";
            this.ButtonSort.UseVisualStyleBackColor = false;
            this.ButtonSort.Click += new System.EventHandler(this.ButtonSort_Click);
            // 
            // ArchivePanel
            // 
            this.ArchivePanel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ArchivePanel.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ArchivePanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ArchivePanel.Controls.Add(this.MainPanel);
            this.ArchivePanel.Controls.Add(this.ListOfCriminals);
            this.ArchivePanel.Location = new System.Drawing.Point(12, 176);
            this.ArchivePanel.Name = "ArchivePanel";
            this.ArchivePanel.Size = new System.Drawing.Size(1158, 517);
            this.ArchivePanel.TabIndex = 26;
            // 
            // MainPanel
            // 
            this.MainPanel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.MainPanel.AutoSize = true;
            this.MainPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MainPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainPanel.Location = new System.Drawing.Point(440, 14);
            this.MainPanel.Name = "MainPanel";
            this.MainPanel.Padding = new System.Windows.Forms.Padding(10);
            this.MainPanel.Size = new System.Drawing.Size(257, 51);
            this.MainPanel.TabIndex = 11;
            this.MainPanel.Text = "Результати пошуку:";
            this.MainPanel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ListOfCriminals
            // 
            this.ListOfCriminals.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ListOfCriminals.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ListOfCriminals.FormattingEnabled = true;
            this.ListOfCriminals.ItemHeight = 29;
            this.ListOfCriminals.Location = new System.Drawing.Point(33, 90);
            this.ListOfCriminals.Name = "ListOfCriminals";
            this.ListOfCriminals.Size = new System.Drawing.Size(1089, 379);
            this.ListOfCriminals.TabIndex = 0;
            this.ListOfCriminals.SelectedIndexChanged += new System.EventHandler(this.ListOfCriminals_SelectedIndexChanged);
            // 
            // BackButton
            // 
            this.BackButton.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.BackButton.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.BackButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BackButton.Location = new System.Drawing.Point(12, 14);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(60, 60);
            this.BackButton.TabIndex = 25;
            this.BackButton.Text = "←";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(418, 9);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(10);
            this.label1.Size = new System.Drawing.Size(333, 51);
            this.label1.TabIndex = 28;
            this.label1.Text = "Заповніть дані для пошуку";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ButtonRefresh
            // 
            this.ButtonRefresh.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ButtonRefresh.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ButtonRefresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonRefresh.Location = new System.Drawing.Point(858, 123);
            this.ButtonRefresh.Name = "ButtonRefresh";
            this.ButtonRefresh.Size = new System.Drawing.Size(153, 47);
            this.ButtonRefresh.TabIndex = 31;
            this.ButtonRefresh.Text = "Оновити";
            this.ButtonRefresh.UseVisualStyleBackColor = false;
            this.ButtonRefresh.Click += new System.EventHandler(this.ButtonRefresh_Click);
            // 
            // SearchForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(1182, 703);
            this.Controls.Add(this.ButtonRefresh);
            this.Controls.Add(this.SearchButton);
            this.Controls.Add(this.SearchBox);
            this.Controls.Add(this.ButtonSort);
            this.Controls.Add(this.ArchivePanel);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.label1);
            this.Name = "SearchForm";
            this.Text = "Search";
            this.ArchivePanel.ResumeLayout(false);
            this.ArchivePanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button SearchButton;
        private System.Windows.Forms.TextBox SearchBox;
        private System.Windows.Forms.Button ButtonSort;
        private System.Windows.Forms.Panel ArchivePanel;
        private System.Windows.Forms.Label MainPanel;
        public System.Windows.Forms.ListBox ListOfCriminals;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button ButtonRefresh;
    }
}