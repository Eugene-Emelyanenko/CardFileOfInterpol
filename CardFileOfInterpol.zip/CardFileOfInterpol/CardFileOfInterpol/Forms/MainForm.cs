﻿using CardFileOfInterpol.Data;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace CardFileOfInterpol
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            DateOfProgram.archive = Serialization.DeserializeObjects(Serialization.DATA_PATH_ARCHIVE);
            Serialization.SerializeObjects(DateOfProgram.archive, Serialization.DATA_PATH_ARCHIVE);
            DateOfProgram.criminals = Serialization.DeserializeObjects();
            if (DateOfProgram.criminals.Count == 0)
            {
                DateOfProgram.criminals = GenerateCriminals();
            }
            Serialization.SerializeObjects(DateOfProgram.criminals);
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            SearchForm searchForm = new SearchForm();
            searchForm.FormClosed += (eventSender, eventArgs) => Show();
            searchForm.Show();
            Hide();
        }

        private void ArchiveButton_Click(object sender, EventArgs e)
        {
            ArchiveForm archiveForm = new ArchiveForm();
            archiveForm.FormClosed += (eventSender, eventArgs) => Show();
            archiveForm.Show();
            Hide();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private List<Criminal> GenerateCriminals()
        {
            string[] names = { "John", "Emma", "Michael", "Olivia", "William", "Ava", "James", "Sophia", "Benjamin", "Isabella" };
            string[] secondNames = { "Smith", "Johnson", "Williams", "Jones", "Brown", "Davis", "Miller", "Wilson", "Moore", "Taylor" };
            string[] citizenships = { "United States", "Canada", "United Kingdom", "Australia", "Germany", "France", "Spain", "Italy", "Japan", "China" };
            string[] criminalProfessions = { "Hitman", "Thief", "Hacker", "Smuggler", "Drug Dealer", "Blackmailer", "Gang Leader", "Forgery Expert", "Bank Robber", "Assassin" };
            string[] aliases = { "Shadow", "Spike", "Viper", "Raven", "Wolf", "Phoenix", "Scar", "Ghost", "Ace", "Joker" };
            string[] groups = { "Syndicate", "Mafia", "Cartel", "Chickens", "Dogs", "Nightfall", "Blood", "Cartel", "Wolves", "Phoenix" };
            string[] colors = { "Red", "Blue", "Green", "Yellow", "Orange", "Purple", "Pink", "Black", "White", "Gray" };
            string[] omens = { "Tattooed", "Scarred", "Mysterious", "Dangerous", "Deceptive", "Evasive", "Reckless", "Cunning", "Intimidating", "Elusive" };
            string[] cities = { "London", "New York", "Paris", "Tokyo", "Sydney", "Berlin", "Rome", "Dubai", "Africa", "Toronto" };
            string[] languages = { "English", "Spanish", "French", "German", "Italian", "Brazil", "Chinese", "Japanese", "Arabic", "Portuguese" };
            string[] lastThings = { "Bank robbery", "Murder", "Drug trafficking", "Fraud", "Piracy", "Kidnapping", "Hacking", "vandalism", "Bribery of officials", "Terrorism" };
            bool[] alive = { true, true, false, true, true};

            List<Criminal> list = new List<Criminal>();
            Random r = new Random();
            for (int i = 0; i < 10; i++)
            {               
                list.Add(new Criminal
                {
                    Name = names[r.Next(0, 10)],
                    SecondName = secondNames[r.Next(0, 10)],
                    CitiezenShip = citizenships[r.Next(0, 10)],
                    CriminalProfession = criminalProfessions[r.Next(0, 10)],
                    GroupName = groups[r.Next(0, 10)],
                    Alias = aliases[r.Next(0, 10)],
                    EyeColor = colors[r.Next(0, 10)],
                    HairColor = colors[r.Next(0, 10)],
                    Omens = new string[] { omens[r.Next(0, 10)] },
                    PlaceOfBirth = cities[r.Next(0, 10)],
                    DateOfBirth = new DateTime(r.Next(1950, 2006), r.Next(1, 13), r.Next(1, 32)),
                    LastPlaceOfLiving = cities[r.Next(0, 10)],
                    Languages = new string[] { languages[r.Next(0, 10)] },
                    LastThing = lastThings[r.Next(0, 10)],
                    Alive = alive[r.Next(0, 5)],
                    Height = r.Next(150, 200),
                });
            }
            return list;
        }
    }
}
