﻿using CardFileOfInterpol.Data;
using System;
using System.Windows.Forms;

namespace CardFileOfInterpol
{
    public partial class ArchiveForm : Form
    {
        public ArchiveForm()
        {
            InitializeComponent();
            DateOfProgram.archive = Serialization.DeserializeObjects(Serialization.DATA_PATH_ARCHIVE);
            ListOfCriminals.Items.Clear();
            foreach (Criminal criminal in DateOfProgram.archive)
            {
                ListOfCriminals.Items.Add(criminal.GetInfo());
            }        
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ListOfCriminals_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                foreach (Criminal criminal in DateOfProgram.archive)
                {
                    if (criminal.GetInfo() == ListOfCriminals.SelectedItem.ToString())
                    {
                        InfoForm infoForm = new InfoForm(criminal);
                        infoForm.FormClosed += (eventSender, eventArgs) => Show();
                        infoForm.Show();
                        Hide();
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Оберіть злочинця");
            }
        }

        private void ButtonRefresh_Click(object sender, EventArgs e)
        {
            DateOfProgram.archive = Serialization.DeserializeObjects(Serialization.DATA_PATH_ARCHIVE);
            ListOfCriminals.Items.Clear();
            foreach (Criminal criminal in DateOfProgram.archive)
            {
                ListOfCriminals.Items.Add(criminal.GetInfo());
            }
        }
    }
}
