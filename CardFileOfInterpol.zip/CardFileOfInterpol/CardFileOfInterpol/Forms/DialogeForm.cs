﻿using System;
using System.Windows.Forms;

namespace CardFileOfInterpol
{
    public partial class DialogeForm : Form
    {
        public DialogeForm()
        {
            InitializeComponent();
        }

        private void ButtonOK_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }

        private void ButtonCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
    }
}
