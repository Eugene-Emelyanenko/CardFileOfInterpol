﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace CardFileOfInterpol
{
    public partial class GroupInfoForm : Form
    {
        List<Criminal> criminalGroup = new List<Criminal>();
        public GroupInfoForm()
        {
            InitializeComponent();
        }
        public GroupInfoForm(string groupName)
        {
            InitializeComponent();
            MainPanel.Text = $"Співучасники групи \"{groupName}\"";
            MainPanel.Location = new Point(this.Width / 2 - MainPanel.Width / 2, 15);
            foreach (Criminal criminal in DateOfProgram.criminals)
            {
                if (criminal.GroupName == groupName)
                {
                    criminalGroup.Add(criminal);
                    ListOfCriminals.Items.Add(criminal.GetInfo());
                }
            }
            foreach (Criminal criminal in DateOfProgram.archive)
            {
                if (criminal.GroupName == groupName)
                {
                    criminalGroup.Add(criminal);
                    ListOfCriminals.Items.Add(criminal.GetInfo());
                }
            }
        }

        private void ListOfCriminals_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                foreach (Criminal criminal in DateOfProgram.criminals)
                {
                    if (criminal.GetInfo() == ListOfCriminals.SelectedItem.ToString())
                    {
                        InfoForm infoForm = new InfoForm(criminal);
                        infoForm.buttonGroupInfo.Visible = false;
                        infoForm.FormClosed += (eventSender, eventArgs) => Show();
                        infoForm.Show();
                        Hide();
                    }
                }
                foreach (Criminal criminal in DateOfProgram.archive)
                {
                    if (criminal.GetInfo() == ListOfCriminals.SelectedItem.ToString())
                    {
                        InfoForm infoForm = new InfoForm(criminal);
                        infoForm.buttonGroupInfo.Visible = false;
                        infoForm.FormClosed += (eventSender, eventArgs) => Show();
                        infoForm.Show();
                        Hide();
                    }
                }

            }
            catch (Exception)
            {
                MessageBox.Show("Оберіть злочинця");
            }

        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ButtonRefresh_Click(object sender, EventArgs e)
        {
            ListOfCriminals.Items.Clear();
            foreach (Criminal criminal in criminalGroup)
            {
                ListOfCriminals.Items.Add(criminal.GetInfo());
            }
        }

        private void ButtonSort_Click(object sender, EventArgs e)
        {
            criminalGroup.Sort((c1, c2) => string.Compare(c1.Name, c2.Name, StringComparison.Ordinal));
            ListOfCriminals.Items.Clear();
            foreach (Criminal criminal in criminalGroup)
            {
                ListOfCriminals.Items.Add(criminal.GetInfo());
            }
        }
    }
}
