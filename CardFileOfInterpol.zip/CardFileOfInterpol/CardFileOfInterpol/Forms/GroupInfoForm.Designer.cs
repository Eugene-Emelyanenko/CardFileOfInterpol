﻿namespace CardFileOfInterpol
{
    partial class GroupInfoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ButtonRefresh = new System.Windows.Forms.Button();
            this.ButtonSort = new System.Windows.Forms.Button();
            this.ArchivePanel = new System.Windows.Forms.Panel();
            this.ListOfCriminals = new System.Windows.Forms.ListBox();
            this.MainPanel = new System.Windows.Forms.Label();
            this.BackButton = new System.Windows.Forms.Button();
            this.ArchivePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // ButtonRefresh
            // 
            this.ButtonRefresh.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ButtonRefresh.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ButtonRefresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonRefresh.Location = new System.Drawing.Point(858, 27);
            this.ButtonRefresh.Name = "ButtonRefresh";
            this.ButtonRefresh.Size = new System.Drawing.Size(153, 47);
            this.ButtonRefresh.TabIndex = 38;
            this.ButtonRefresh.Text = "Оновити";
            this.ButtonRefresh.UseVisualStyleBackColor = false;
            this.ButtonRefresh.Click += new System.EventHandler(this.ButtonRefresh_Click);
            // 
            // ButtonSort
            // 
            this.ButtonSort.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ButtonSort.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ButtonSort.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonSort.Location = new System.Drawing.Point(1017, 27);
            this.ButtonSort.Name = "ButtonSort";
            this.ButtonSort.Size = new System.Drawing.Size(153, 47);
            this.ButtonSort.TabIndex = 34;
            this.ButtonSort.Text = "Відсортирувати за алфавітом";
            this.ButtonSort.UseVisualStyleBackColor = false;
            this.ButtonSort.Click += new System.EventHandler(this.ButtonSort_Click);
            // 
            // ArchivePanel
            // 
            this.ArchivePanel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ArchivePanel.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ArchivePanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ArchivePanel.Controls.Add(this.ListOfCriminals);
            this.ArchivePanel.Location = new System.Drawing.Point(12, 80);
            this.ArchivePanel.Name = "ArchivePanel";
            this.ArchivePanel.Size = new System.Drawing.Size(1158, 613);
            this.ArchivePanel.TabIndex = 33;
            // 
            // ListOfCriminals
            // 
            this.ListOfCriminals.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ListOfCriminals.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ListOfCriminals.FormattingEnabled = true;
            this.ListOfCriminals.ItemHeight = 29;
            this.ListOfCriminals.Location = new System.Drawing.Point(33, 61);
            this.ListOfCriminals.Name = "ListOfCriminals";
            this.ListOfCriminals.Size = new System.Drawing.Size(1089, 495);
            this.ListOfCriminals.TabIndex = 0;
            this.ListOfCriminals.SelectedIndexChanged += new System.EventHandler(this.ListOfCriminals_SelectedIndexChanged);
            // 
            // MainPanel
            // 
            this.MainPanel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.MainPanel.AutoSize = true;
            this.MainPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MainPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainPanel.Location = new System.Drawing.Point(480, 14);
            this.MainPanel.Name = "MainPanel";
            this.MainPanel.Padding = new System.Windows.Forms.Padding(10);
            this.MainPanel.Size = new System.Drawing.Size(261, 51);
            this.MainPanel.TabIndex = 11;
            this.MainPanel.Text = "Співучасники групи:";
            this.MainPanel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BackButton
            // 
            this.BackButton.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.BackButton.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.BackButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BackButton.Location = new System.Drawing.Point(12, 14);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(60, 60);
            this.BackButton.TabIndex = 32;
            this.BackButton.Text = "←";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // GroupInfoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(1182, 703);
            this.Controls.Add(this.MainPanel);
            this.Controls.Add(this.ButtonRefresh);
            this.Controls.Add(this.ButtonSort);
            this.Controls.Add(this.ArchivePanel);
            this.Controls.Add(this.BackButton);
            this.Name = "GroupInfoForm";
            this.Text = "Group Info";
            this.ArchivePanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ButtonRefresh;
        private System.Windows.Forms.Button ButtonSort;
        private System.Windows.Forms.Panel ArchivePanel;
        public System.Windows.Forms.ListBox ListOfCriminals;
        private System.Windows.Forms.Label MainPanel;
        private System.Windows.Forms.Button BackButton;
    }
}