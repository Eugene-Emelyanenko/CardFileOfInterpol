﻿using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace CardFileOfInterpol.Data
{
    public static class Serialization
    {
        public const string DATA_PATH_CRIMINALS = "C:\\Users\\emely\\source\\repos\\CardFileOfInterpol\\CardFileOfInterpol\\Data\\DateOfCriminals.xml";
        public const string DATA_PATH_ARCHIVE = "C:\\Users\\emely\\source\\repos\\CardFileOfInterpol\\CardFileOfInterpol\\Data\\DateOfArchive.xml";
        public static void SerializeObjects(List<Criminal> criminals, string DATA_PATH = DATA_PATH_CRIMINALS)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<Criminal>));

            using (FileStream fileStream = new FileStream(DATA_PATH, FileMode.Create))
            {
                serializer.Serialize(fileStream, criminals);
            }
        }
        public static List<Criminal> DeserializeObjects(string DATA_PATH = DATA_PATH_CRIMINALS)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<Criminal>));

            using (FileStream fileStream = new FileStream(DATA_PATH, FileMode.Open))
            {
                return (List<Criminal>)serializer.Deserialize(fileStream);
            }
        }
    }
}
