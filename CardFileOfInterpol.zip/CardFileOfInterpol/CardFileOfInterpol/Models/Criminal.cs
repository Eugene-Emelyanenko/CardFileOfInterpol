﻿using System;

namespace CardFileOfInterpol
{
    public class Criminal
    {
        public string Name;

        public string SecondName;

        public int Height;

        public string CitiezenShip;

        public string CriminalProfession;

        public string GroupName;

        public string Alias;

        public string EyeColor;

        public string HairColor;

        public string[] Omens;

        public string PlaceOfBirth;

        public DateTime DateOfBirth;

        public string LastPlaceOfLiving;

        public string[] Languages;

        public string LastThing;

        public bool? Alive;

        public Criminal() 
        {
            Name = string.Empty;
            SecondName = string.Empty;
            CitiezenShip = string.Empty;
            CriminalProfession = string.Empty;
            GroupName = string.Empty;
            Alias = string.Empty;
            EyeColor = string.Empty;
            HairColor = string.Empty;
            Omens = new string[] { };
            PlaceOfBirth = string.Empty;
            DateOfBirth = DateTime.Now;
            LastPlaceOfLiving = string.Empty;
            Languages = new string[] { };
            LastThing = string.Empty;
            Alive = null;
        }

        public Criminal(string name, string secondName, string citiezenShip, string criminalProfession, string groupName, string alias, string eyeColor,
                        string hairColor, string[] omens, string placeOfBirth, DateTime dateOfBirth, string lastPlaceOfLiving, string[] languages,
                        string lastThing, bool alive, int height)
        {
            Name = name;
            SecondName = secondName;
            CitiezenShip = citiezenShip;
            CriminalProfession = criminalProfession;
            GroupName = groupName;
            Alias = alias;
            EyeColor = eyeColor;
            HairColor = hairColor;
            Omens = omens;
            PlaceOfBirth = placeOfBirth;
            DateOfBirth = dateOfBirth;
            LastPlaceOfLiving = lastPlaceOfLiving;
            Languages = languages;
            LastThing = lastThing;
            Alive = alive;
            Height = height;
        }

        public string GetOmens()
        {
            string str = "";
            for (int i = 0; i < Omens.Length; i++)
            {
                if(i == Omens.Length - 1)
                {
                    str += Omens[i];
                }
                else
                {
                    str += Omens[i] + ", ";
                }
            }
            return str;
        }

        public string GetLanguages()
        {
            string str = "";
            for (int i = 0; i < Languages.Length; i++)
            {
                if (i == Omens.Length - 1)
                {
                    str += Languages[i];
                }
                else
                {
                    str += Languages[i] + ", ";
                }
            }
            return str;
        }

        public override string ToString()
        {
            return $"{Name}, {SecondName}, {Height}, {CitiezenShip}, {CriminalProfession}, {GroupName}, {Alias}, {EyeColor}, {HairColor}," +
                   $"{GetOmens()}, {PlaceOfBirth}, {DateOfBirth.ToString("dd'/'MM'/'yyyy")}, {LastPlaceOfLiving}, {GetLanguages()}, {LastThing}, {Alive}";
        }

        public string GetInfo()
        {
            return $"{Name}\t\t\t\t{SecondName}\t\t\t{DateOfBirth.ToString("dd'/'MM'/'yyyy")}";
        }
    }
}
