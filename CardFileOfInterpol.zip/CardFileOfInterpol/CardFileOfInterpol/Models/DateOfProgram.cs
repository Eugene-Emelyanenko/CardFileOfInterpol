﻿using System.Collections.Generic;

namespace CardFileOfInterpol
{
    internal static class DateOfProgram
    {
        public static List<Criminal> criminals = new List<Criminal>();
        public static List<Criminal> archive = new List<Criminal>();
        public static Criminal currentCriminal = new Criminal();
        public static List<Criminal> SearchedCriminals = new List<Criminal>();
    }
}
